﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMP123_S2019_Lab10_300983741
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_AutoValidateChanged(object sender, EventArgs e)
        {

        }

        private void Form1_AutoSizeChanged(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void RadioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double WeightInPounds;
            double HeightInInches;
            double WeightInKilograms;
            double HeightInMeters;
            double BMI1;
            double BMI2;
            WeightInPounds = double.Parse(weighttxx.Text);
            WeightInKilograms = double.Parse(weighttxx.Text);
            HeightInInches = double.Parse(heighttxx.Text);
            HeightInMeters= double.Parse(heighttxx.Text);
            BMI1 = (WeightInPounds * 703) / (HeightInInches * HeightInInches);
            BMI2 = (WeightInKilograms) / (HeightInMeters * HeightInMeters);
            if (BMI1 < 18.5 || BMI2 < 18.5)
            {
                Result.Text = $"{BMI1}";
                Scale.Text = "UnderWeight";
            }
            else if (BMI1>= 18.5 && BMI1<24.9 || BMI2 >=18.5 && BMI2 <24.9)
            {
                Result.Text = $"{BMI1}";
                Scale.Text = "Normal";
            }
            else if (BMI1 >= 25 && BMI1 < 29.9 || BMI2 >= 25 && BMI2 < 29.9)
            {
                Result.Text = $"{BMI1}";
                Scale.Text = "Overweight";
            }
            else if (BMI1 >= 30 || BMI2 >= 30)
            {
                Result.Text = $"{BMI1}";
                Scale.Text = "Obese";
            }

        }

        private void Weighttxx_TextChanged(object sender, EventArgs e)
        {

        }

        private void Heighttxx_TextChanged(object sender, EventArgs e)
        {

        }

        private void Imperial2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }

        private void Metric1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
