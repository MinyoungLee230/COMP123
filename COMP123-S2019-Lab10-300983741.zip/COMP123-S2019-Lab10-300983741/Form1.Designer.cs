﻿namespace COMP123_S2019_Lab10_300983741
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.Weight = new System.Windows.Forms.Label();
            this.Height = new System.Windows.Forms.Label();
            this.heighttxx = new System.Windows.Forms.TextBox();
            this.weighttxx = new System.Windows.Forms.TextBox();
            this.Imperial1 = new System.Windows.Forms.RadioButton();
            this.Metric1 = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.BMIresult = new System.Windows.Forms.Label();
            this.Result = new System.Windows.Forms.TextBox();
            this.BMIscale = new System.Windows.Forms.Label();
            this.Scale = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Weight
            // 
            this.Weight.AutoSize = true;
            this.Weight.Location = new System.Drawing.Point(27, 69);
            this.Weight.Name = "Weight";
            this.Weight.Size = new System.Drawing.Size(103, 32);
            this.Weight.TabIndex = 0;
            this.Weight.Text = "Weight:";
            this.Weight.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Height
            // 
            this.Height.AutoSize = true;
            this.Height.Location = new System.Drawing.Point(27, 17);
            this.Height.Name = "Height";
            this.Height.Size = new System.Drawing.Size(99, 32);
            this.Height.TabIndex = 1;
            this.Height.Text = "Height:";
            // 
            // heighttxx
            // 
            this.heighttxx.Location = new System.Drawing.Point(136, 10);
            this.heighttxx.Name = "heighttxx";
            this.heighttxx.Size = new System.Drawing.Size(100, 39);
            this.heighttxx.TabIndex = 2;
            this.heighttxx.TextChanged += new System.EventHandler(this.Heighttxx_TextChanged);
            // 
            // weighttxx
            // 
            this.weighttxx.Location = new System.Drawing.Point(136, 62);
            this.weighttxx.Name = "weighttxx";
            this.weighttxx.Size = new System.Drawing.Size(100, 39);
            this.weighttxx.TabIndex = 3;
            this.weighttxx.TextChanged += new System.EventHandler(this.Weighttxx_TextChanged);
            // 
            // Imperial1
            // 
            this.Imperial1.AutoSize = true;
            this.Imperial1.Location = new System.Drawing.Point(12, 114);
            this.Imperial1.Name = "Imperial1";
            this.Imperial1.Size = new System.Drawing.Size(131, 36);
            this.Imperial1.TabIndex = 4;
            this.Imperial1.TabStop = true;
            this.Imperial1.Text = "Imperial";
            this.Imperial1.UseVisualStyleBackColor = true;
            this.Imperial1.CheckedChanged += new System.EventHandler(this.RadioButton1_CheckedChanged);
            // 
            // Metric1
            // 
            this.Metric1.AutoSize = true;
            this.Metric1.Location = new System.Drawing.Point(149, 114);
            this.Metric1.Name = "Metric1";
            this.Metric1.Size = new System.Drawing.Size(108, 36);
            this.Metric1.TabIndex = 5;
            this.Metric1.TabStop = true;
            this.Metric1.Text = "Metric";
            this.Metric1.UseVisualStyleBackColor = true;
            this.Metric1.CheckedChanged += new System.EventHandler(this.Metric1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 174);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(185, 42);
            this.button1.TabIndex = 8;
            this.button1.Text = "Calculate BMI";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(194, 174);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 42);
            this.button2.TabIndex = 9;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // BMIresult
            // 
            this.BMIresult.AutoSize = true;
            this.BMIresult.Location = new System.Drawing.Point(12, 235);
            this.BMIresult.Name = "BMIresult";
            this.BMIresult.Size = new System.Drawing.Size(155, 32);
            this.BMIresult.TabIndex = 10;
            this.BMIresult.Text = "BMI Result: ";
            // 
            // Result
            // 
            this.Result.Location = new System.Drawing.Point(173, 232);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(100, 39);
            this.Result.TabIndex = 11;
            // 
            // BMIscale
            // 
            this.BMIscale.AutoSize = true;
            this.BMIscale.Location = new System.Drawing.Point(12, 286);
            this.BMIscale.Name = "BMIscale";
            this.BMIscale.Size = new System.Drawing.Size(140, 32);
            this.BMIscale.TabIndex = 12;
            this.BMIscale.Text = "BMI Scale: ";
            // 
            // Scale
            // 
            this.Scale.Location = new System.Drawing.Point(173, 283);
            this.Scale.Name = "Scale";
            this.Scale.Size = new System.Drawing.Size(100, 39);
            this.Scale.TabIndex = 13;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(15F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(304, 441);
            this.Controls.Add(this.Scale);
            this.Controls.Add(this.BMIscale);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.BMIresult);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Metric1);
            this.Controls.Add(this.Imperial1);
            this.Controls.Add(this.weighttxx);
            this.Controls.Add(this.heighttxx);
            this.Controls.Add(this.Height);
            this.Controls.Add(this.Weight);
            this.Font = new System.Drawing.Font("Cambria", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.AutoSizeChanged += new System.EventHandler(this.Form1_AutoSizeChanged);
            this.AutoValidateChanged += new System.EventHandler(this.Form1_AutoValidateChanged);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Weight;
        private System.Windows.Forms.Label Height;
        private System.Windows.Forms.TextBox heighttxx;
        private System.Windows.Forms.TextBox weighttxx;
        private System.Windows.Forms.RadioButton Imperial1;
        private System.Windows.Forms.RadioButton Metric1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label BMIresult;
        private System.Windows.Forms.TextBox Result;
        private System.Windows.Forms.Label BMIscale;
        private System.Windows.Forms.TextBox Scale;
    }
}

